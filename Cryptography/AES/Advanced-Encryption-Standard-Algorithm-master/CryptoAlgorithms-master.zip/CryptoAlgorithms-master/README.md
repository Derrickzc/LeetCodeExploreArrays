# CryptoAlgorithms
RC4, Huffman and Rijndael
